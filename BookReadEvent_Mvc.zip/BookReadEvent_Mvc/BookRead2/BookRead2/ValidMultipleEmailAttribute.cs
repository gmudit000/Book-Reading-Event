﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;
using System.Linq;
using System.Web;

namespace BookRead2
{
    public class ValidMultipleEmailAttribute : ValidationAttribute
    {
        public List<string> GetEmails(string emails)
        {
            // remove space from string
            string emailsWithoutspace = emails;
            emailsWithoutspace = emailsWithoutspace.Replace(" ", "");

            List<string> result = new List<string>();

            while (true)
            {
                int position_of_at = emailsWithoutspace.IndexOf("@");
                if (position_of_at == -1)
                {
                    break;
                }

                int position_of_comma = emailsWithoutspace.IndexOf(",", position_of_at);

                if (position_of_comma == -1)
                {
                    result.Add(emailsWithoutspace);
                    break;
                }

                string emailRes = emailsWithoutspace.Substring(0, position_of_comma);
                result.Add(emailRes);
                emailsWithoutspace = emailsWithoutspace.Substring(position_of_comma + 1);
            }
            return result;
        }

        public override bool IsValid(object value)
        {
            string emails = value.ToString();
            List<string> result = GetEmails(emails);

            var valid = false;
            // validate email address
            Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");

            for (var i = 0; i < result.Count; i++)
            {
                Match match = regex.Match(result[i]);

                if (match.Success)
                {
                    valid = true;
                }
                else
                {
                    valid = false;
                }
            }
            return valid;
        }
    }
}