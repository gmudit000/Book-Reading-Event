﻿using System;
using System.Collections.Generic;
using BookRead2.Models;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;

namespace BookRead2.Controllers
{
    public class EventController : Controller
    {
        // db context class object
        BookRead2Entities db = new BookRead2Entities();

        // This function will get the emails of invited user to event
        public List<string> GetEmails(string emails)
        {
            // remove space from string
            string emailsWithoutspace = emails;
            emailsWithoutspace = emailsWithoutspace.Replace(" ", "");

            List<string> result = new List<string>();

            while (true)
            {
                int position_of_at = emailsWithoutspace.IndexOf("@");
                if (position_of_at == -1)
                {
                    break;
                }

                int position_of_comma = emailsWithoutspace.IndexOf(",", position_of_at);

                if (position_of_comma == -1)
                {
                    result.Add(emailsWithoutspace);
                    break;
                }

                string emailRes = emailsWithoutspace.Substring(0, position_of_comma);
                result.Add(emailRes);
                emailsWithoutspace = emailsWithoutspace.Substring(position_of_comma + 1);
            }
            return result;
        }

        // GET: All Events
        [Authorize(Roles = "Admin")]
        public ActionResult Index()
        {
            var data = db.Events.ToList();
            return View(data);
        }

        //GET: Create
        [Authorize(Roles = "Admin,User")]
        public ActionResult Create()
        {
            List<int> list = new List<int>() { 00, 01, 02, 03, 04, 05, 06, 07, 08, 09, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23 };
            ViewBag.list = list;
            return View();
        }

        // POST: Create
        [Authorize(Roles = "Admin,User")]
        [HttpPost]
        public ActionResult Create(Event e)
        {
            List<int> list = new List<int>() { 00, 01, 02, 03, 04, 05, 06, 07, 08, 09, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23 };
            ViewBag.list = list;

            if (ModelState.IsValid == true)
            {
                HttpCookie cookie = Request.Cookies["UserInfo"];
                if(cookie != null)
                {
                    e.EventOwnerEmail = cookie["LoginEmailAddress"];
                }

                // data will be saved to database
                db.Events.Add(e);
                int res = db.SaveChanges();
                if(res > 0)
                {
                    return RedirectToAction("Index", "Home");
                }
            }
            return View();
        }

        //GET: Edit
        [Authorize(Roles = "Admin,User")]
        public ActionResult Edit(int id)
        {
            List<int> list = new List<int>() { 00, 01, 02, 03, 04, 05, 06, 07, 08, 09, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23 };
            ViewBag.list = list;

            // if the event is in past then not allowed to edit
            var EventDate = db.Events.Find(id).Date;
            var CurrentDate = DateTime.Now;
            int res = DateTime.Compare(EventDate, CurrentDate);

            if (res < 0)
            {
                return RedirectToAction("MyEvents");
            }

            // else allowed to edit events if it is in future
            var row = db.Events.Where(model => model.EventId == id).FirstOrDefault();
            return View(row);
        }

        // POST: Edit
        [Authorize(Roles = "Admin,User")]
        [HttpPost]
        public ActionResult Edit(Event e)
        {
            List<int> list = new List<int>() { 00, 01, 02, 03, 04, 05, 06, 07, 08, 09, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23 };
            ViewBag.list = list;

            if (ModelState.IsValid == true)
            {
                HttpCookie cookie = Request.Cookies["UserInfo"];
                if (cookie != null)
                {
                    e.EventOwnerEmail = cookie["LoginEmailAddress"];
                }

                db.Entry(e).State = EntityState.Modified;
                int res = db.SaveChanges();
                if (res > 0)
                {
                    return RedirectToAction("Index", "Home");
                }
            }
            return View();
        }

        // GET: Detail
        [AllowAnonymous]
        public ActionResult Detail(int id)
        {
            // calculate total no of invites by email
            var emailString = db.Events.Find(id).InviteByEmail;
            List<string> emailList = GetEmails(emailString);
            var totalInvites = emailList.Count;
            ViewBag.TotalInvitesByEmail = totalInvites;

            var row = db.Events.Where(model => model.EventId == id).FirstOrDefault();
            return View(row);
        }

        // GET: My Events
        [Authorize(Roles = "Admin,User")]
        public ActionResult MyEvents()
        {
            HttpCookie cookie = Request.Cookies["UserInfo"];
            if (cookie != null)
            {
                var userEmail = cookie["LoginEmailAddress"];
                var data = db.Events.Where(model => model.EventOwnerEmail == userEmail).ToList();
                
                // it will order the list for event-start-date-first
                var orderedData = data.OrderBy(x => x.Date).ToList();
                return View(orderedData);
            }
            return RedirectToAction("Index","Home");
        }

        // GET: Events Invited To
        [Authorize(Roles = "Admin,User")]
        public ActionResult EventsInvitedTo()
        {
            HttpCookie cookie = Request.Cookies["UserInfo"];
            if (cookie != null)
            {
                var userEmail = cookie["LoginEmailAddress"];
                var data = db.Events.Where(model => model.InviteByEmail == userEmail).ToList();
                return View(data);
            }
            return RedirectToAction("Index", "Home");
        }

        // Delete Action Methods
        // GET: Events/Delete/id
        [Authorize(Roles = "Admin,User")]
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Event e = db.Events.Find(id);
            if (e == null)
            {
                return HttpNotFound();
            }
            return View(e);
        }

        // POST: Events/Delete/id
        [Authorize(Roles = "Admin,User")]
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Event e = db.Events.Find(id);
            db.Events.Remove(e);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}