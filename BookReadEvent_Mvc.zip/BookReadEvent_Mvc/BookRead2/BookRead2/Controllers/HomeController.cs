﻿using BookRead2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BookRead2.Controllers
{
    [AllowAnonymous]
    public class HomeController : Controller
    {
        BookRead2Entities db = new BookRead2Entities();

        // GET: Home
        // it will list all the public events from database
        public ActionResult Index()
        {
            var data = db.Events.Where(model => model.EventType == "public").ToList();
            return View(data);
        }

        [ActionName("customer-support")]
        public ActionResult Help()
        {
            return Redirect("http://helpdesk.nagarro.com/");
        }
    }
}