﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BookRead2.Models;
using System.Web.Security;

namespace BookRead2.Controllers
{
    [AllowAnonymous]
    public class AccountController : Controller
    {
        // context class object
        BookRead2Entities db = new BookRead2Entities();

        // cookies
        HttpCookie cookie = new HttpCookie("UserInfo");

        // GET: Login
        public ActionResult Login()
        {
            return View();
        }

        // POST: Login
        [HttpPost]
        public ActionResult Login(User user)
        {
            bool isValid = db.Users.Any(x=>x.Email == user.Email && x.Password == user.Password);
            if (isValid)
            {
                // to set the cookie
                cookie["LoginEmailAddress"] = user.Email;
                Response.Cookies.Add(cookie);

                FormsAuthentication.SetAuthCookie(user.Email, false);
                return RedirectToAction("Index", "Home");
            }

            ModelState.AddModelError("", "Invalid email or password");
            return View();
        }

        // GET: Register
        public ActionResult Register()
        {
            return View();
        }

        // POST: Register
        [HttpPost]
        public ActionResult Register(User user)
        {
            try
            {
                // new user data will be stored in User Database
                db.Users.Add(user);
                int res = db.SaveChanges();
                if (res > 0)
                {
                    // Assigning role to the new user
                    db.UserRole.Add(new UserRole{ UserId = user.UserId, Role = "User" });
                    int finalRes = db.SaveChanges();
                    if(finalRes > 0)
                    {
                        return RedirectToAction("Login");
                    }
                }
                return View();
            }
            catch (Exception)
            {
                ModelState.AddModelError("","Email already exists");
                return View();
            }
        }

        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Login");
        }
    }
}