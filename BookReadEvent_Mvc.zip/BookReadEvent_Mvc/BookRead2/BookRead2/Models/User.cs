namespace BookRead2.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class User
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public User()
        {
            this.UserRole = new HashSet<UserRole>();
        }
    
        public int UserId { get; set; }
        [Required]
        [Display(Name = "Full Name")]
        public string FullName { get; set; }

        [Required]
        [EmailAddress(ErrorMessage ="Please enter correct Email syntax")]
        public string Email { get; set; }

        [Required]
        [StringLength(20, MinimumLength = 5,ErrorMessage = "Password must have min length of 5 and max Length of 20")]
        //[RegularExpression(@"^(?=.*[@$!%*?&])$", ErrorMessage ="Password must have at least one special character")]
        public string Password { get; set; }
    
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<UserRole> UserRole { get; set; }
    }
}
