namespace BookRead2.Models
{
    using System;
    using System.Collections.Generic;
    
    public class UserRole
    {
        public int id { get; set; }
        public int UserId { get; set; }
        public string Role { get; set; }
    
        public virtual User User { get; set; }
    }
}
