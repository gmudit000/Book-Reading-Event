namespace BookRead2.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    // Database First Approach
    public class Event
    {
        public int EventId { get; set; }

        [Display(Name = "Event Name")]
        [Required]
        public string Title { get; set; }
        
        [Required]
        public System.DateTime Date { get; set; }
        
        [Required]
        public string Location { get; set; }

        [Display(Name = "Event Type")]
        [Required]
        public string EventType { get; set; }

        [Display(Name = "Event Duration (in hours)")]
        [Range(1, 4, ErrorMessage = "Max number of hours allowed for Event is 4 hours")]
        public Nullable<int> DurationInHours { get; set; }

        [StringLength(50, ErrorMessage = "Please do not enter more than 50 characters")]
        public string Description { get; set; }

        [Display(Name = "Other Details")]
        [StringLength(500, ErrorMessage = "Please do not enter more than 500 characters")]
        public string OtherDetails { get; set; }

        [Required]
        [Display(Name = "Emails to Invite")]
        [ValidMultipleEmail(ErrorMessage = "Please enter Email address in correct format")]
        public string InviteByEmail { get; set; }

        [Display(Name = "Event Owner Email")]
        public string EventOwnerEmail { get; set; }

        [Display(Name = "Start Time")]
        [Required]
        public int StartTime { get; set; }
    }
}
